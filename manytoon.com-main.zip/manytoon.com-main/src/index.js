/**
 * @module manytoon.com
 */
module.exports = exports = {
    Parser: (require('./parser')),
    Doujin: (require('./Doujin')),
    Page: (require('./Page')),
}