Open Facebook API
=================

.. toctree::
   :maxdepth: 2

.. automodule:: open_facebook.api
    :members: OpenFacebook, FacebookAuthorization, FacebookConnection

