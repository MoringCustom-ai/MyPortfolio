Registration backends
=====================

.. toctree::
   :maxdepth: 2

.. automodule:: django_facebook.registration_backends
    :members:

