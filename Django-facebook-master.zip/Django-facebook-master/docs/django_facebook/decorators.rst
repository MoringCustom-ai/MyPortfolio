Decorators
==========

.. toctree::
   :maxdepth: 2

.. automodule:: django_facebook.decorators
    :members: