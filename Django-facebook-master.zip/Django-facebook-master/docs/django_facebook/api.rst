API
===

.. toctree::
   :maxdepth: 2

.. automodule:: django_facebook.api
    :members:

