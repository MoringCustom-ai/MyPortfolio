#!c:\workspace\django_facebook\docs\docs_env\Scripts\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'pip==1.0','console_scripts','pip-2.5'
__requires__ = 'pip==1.0'
import sys
from pkg_resources import load_entry_point

sys.exit(
   load_entry_point('pip==1.0', 'console_scripts', 'pip-2.5')()
)
